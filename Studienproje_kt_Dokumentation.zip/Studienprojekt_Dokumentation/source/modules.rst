Code
====

.. toctree::
   :maxdepth: 4

   cleaning_segmentation
   nlp_filter_
   wget
